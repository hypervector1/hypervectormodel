# HypeVector — real free-stack foundation

This is the first working build: a responsive intelligence dashboard with a real Supabase schema ready for live signal ingestion.

FREE STACK
- GitHub Pages: free frontend hosting
- Supabase Free: database + auth/storage later
- Vanilla HTML/CSS/JS: no paid framework

CURRENT BUILD
- HypeVector dashboard
- Trend ranking
- Search
- Trend detail panel
- HypeVector score presentation
- Velocity/category/forecast panels
- Responsive layout
- Supabase schema for trends, signal events and watchlists
- Transparent starting scoring function

IMPORTANT
The dashboard's displayed trends are demonstration data. Do NOT market them as live measurements yet. The next step is connecting permitted public data sources and writing the ingestion/scoring pipeline.

DEPLOY
1. Create a GitHub repository named hypevector.
2. Upload index.html.
3. GitHub Settings > Pages > deploy main/root.
4. Open Supabase and run supabase.sql in SQL Editor.

NEXT DEVELOPMENT ORDER
1. Build source ingestion tables and collectors.
2. Add a server-side scheduled job/edge function for permitted sources.
3. Normalize signals.
4. Calculate velocity + acceleration + spread + adoption + longevity.
5. Persist score history.
6. Build real charts and trend pages.
7. Add authentication/watchlists/alerts.
8. Add moderation and source attribution.
9. Add paid tier only after usage proves demand.

DO NOT put Supabase service_role keys in browser code.
