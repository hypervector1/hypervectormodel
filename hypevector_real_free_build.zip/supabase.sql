-- HYPEVECTOR FOUNDATION — SUPABASE
-- Run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.trends (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 category text not null,
 source text,
 score numeric(5,2) not null default 0,
 velocity numeric(8,2) not null default 0,
 acceleration numeric(8,2) not null default 0,
 spread numeric(8,2) not null default 0,
 adoption numeric(8,2) not null default 0,
 longevity numeric(8,2) not null default 0,
 status text not null default 'RISING',
 first_seen timestamptz not null default now(),
 last_seen timestamptz not null default now(),
 metadata jsonb not null default '{}'::jsonb
);

create table if not exists public.signal_events (
 id uuid primary key default gen_random_uuid(),
 trend_id uuid references public.trends(id) on delete cascade,
 source text not null,
 event_type text,
 value numeric,
 observed_at timestamptz not null default now(),
 raw jsonb not null default '{}'::jsonb
);

create table if not exists public.watchlists (
 user_id uuid references auth.users(id) on delete cascade,
 trend_id uuid references public.trends(id) on delete cascade,
 created_at timestamptz not null default now(),
 primary key(user_id,trend_id)
);

alter table public.trends enable row level security;
alter table public.signal_events enable row level security;
alter table public.watchlists enable row level security;

create policy "public can read trends" on public.trends for select using (true);
create policy "public can read signals" on public.signal_events for select using (true);
create policy "users manage own watchlist" on public.watchlists for all using(auth.uid()=user_id) with check(auth.uid()=user_id);

-- Score formula: transparent starting point, not a claim of predictive certainty.
create or replace function public.calculate_hype_score(
 p_velocity numeric, p_acceleration numeric, p_spread numeric,
 p_adoption numeric, p_longevity numeric
) returns numeric language sql immutable as $$
 select round(least(100,greatest(0,
   p_velocity*0.30 +
   p_acceleration*0.20 +
   p_spread*0.20 +
   p_adoption*0.20 +
   p_longevity*0.10
 ))::numeric,1);
$$;
